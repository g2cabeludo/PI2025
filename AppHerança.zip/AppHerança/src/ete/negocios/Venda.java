package ete.negocios;
import java.util.Date;
import java.util.List;


public class Venda {
    public int id_venda;
    public Cliente cliente;
    public Date data_venda;
    public double valor_total;
    public List<ItemVenda> itens;
    
    public Venda(int id_venda, Cliente cliente, Date data_venda, double valor_total, List<ItemVenda> itens){
        this.id_venda = id_venda;
        this.cliente = cliente;
        this.data_venda = data_venda;
        this.valor_total = valor_total;
        this.itens = itens;
    }

    public int getId() {
        return id_venda;
    }

    public void setId(int id) {
        this.id_venda = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Date getData_venda() {
        return data_venda;
    }

    public void setData_venda(Date data_venda) {
        this.data_venda = data_venda;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }

    public void setItens(List<ItemVenda> itens) {
        this.itens = itens;
    }
    
}
