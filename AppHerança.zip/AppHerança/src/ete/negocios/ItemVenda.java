
package ete.negocios;

public class ItemVenda {
    public int id;
    public Produto produto;
    public int quantidade;
    private double preco_unid;
    
    public ItemVenda(int id, Produto produto, int quantidade, double preco_unid){
        this.id = id;
        this.produto = produto;
        this.quantidade = quantidade;
        this.preco_unid = preco_unid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco_unid() {
        return preco_unid;
    }

    public void setPreco_unid(double preco_unid) {
        this.preco_unid = preco_unid;
    }
    
}
