
package ete.negocios;

public class Produto {
    public int id_produto;
    public String nome;
    public String descricao;
    public int quantidade;
    public double preco;
    
    public Produto (int id, String nome, String descricao, int quantidade, double preco){
        this.id_produto = id;
        this.nome = nome;
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.preco = preco;
    }

    public int getId() {
        return id_produto;
    }

    public void setId(int id) {
        this.id_produto = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
    
}
