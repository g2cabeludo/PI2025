package ete.negocios;
public class Cliente extends Pessoa {
    public Cliente(){
        
    }
    
}
