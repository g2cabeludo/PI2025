package ete.negocios;


import ete.negocios.Funcion�rio;

import java.util.Date;


public class Principal {
    public static void main(String[] args) {
        
        Funcion�rio a = new Funcion�rio("Cleber Machado", "123.456.789.30", new Date(), 1.234, new Date(), "admin");
        System.out.println("Aributos de Funcion�rio \n\nNome:  "+a.nome);
        System.out.println("CPF: "+a.cpf);
        System.out.println("Data de nascimento: "+a.data_nascimento);
        System.out.println("Salario: "+a.salario);
        System.out.println("Data de admiss�o: "+a.data_admissao);
        System.out.println("Carfo: "+a.cargo);
        
        
    }
    
}
