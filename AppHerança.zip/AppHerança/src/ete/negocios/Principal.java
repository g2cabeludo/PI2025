package ete.negocios;


import ete.negocios.Funcion�rio;

import java.util.Date;


public class Principal {
    public static void main(String[] args) {
        
        Funcion�rio a = new Funcion�rio(1,"BIUZIN DO FARELO", "123.456.789.30", new Date(),"admin");
        System.out.println("ID: "+a.getId_Funcionario());
        System.out.println("Aributos de Funcion�rio \n\nNome:  "+a.getNome());
        System.out.println("CPF: "+a.getCpf());
        System.out.println("Data de nascimento: "+a.getData_nascimento());
        System.out.println("Cargo: "+a.getCargo());
        
        
    }
    
}
