package ete.pirepositorio;

import ete.negocios.Funcion�rio;
import ete.banco.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RepFuncionario { //senha com md5 n�o aparece no bd!!
    
    Connection con;
    
    public boolean inserir(Funcion�rio funcion�rio) throws SQLException{
        
        con = (Connection)
    }
    
}
