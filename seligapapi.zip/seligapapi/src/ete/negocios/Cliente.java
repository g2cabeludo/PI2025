package ete.negocios;

import java.util.Date;

public class Cliente extends Pessoa {
    private String telefone;
    private String senha;
    public Cliente(String nome, String cpf, Date data, String telefone, int id){
        super(nome, cpf, data, id);
        this.telefone = telefone;
        this.senha = senha;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
   