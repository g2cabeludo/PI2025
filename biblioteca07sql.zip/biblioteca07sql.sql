CREATE TABLE IF NOT EXISTS public.cliente
(
    id_cliente integer NOT NULL DEFAULT nextval('cliente_id_cliente_seq'::regclass),
    no_cliente character varying(60) COLLATE pg_catalog."default" NOT NULL,
    cpf character varying(11) COLLATE pg_catalog."default" NOT NULL,
    telefone character varying(15) COLLATE pg_catalog."default",
    senha character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT cliente_pkey PRIMARY KEY (id_cliente),
    CONSTRAINT cliente_cpf_key UNIQUE (cpf)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.cliente
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.funcionarios
(
    id_funcionario integer NOT NULL DEFAULT nextval('funcionarios_id_funcionario_seq'::regclass),
    no_funcionario character varying(60) COLLATE pg_catalog."default" NOT NULL,
    cpf character varying(11) COLLATE pg_catalog."default",
    telefone character varying(15) COLLATE pg_catalog."default",
    senha character varying(100) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT funcionarios_pkey PRIMARY KEY (id_funcionario),
    CONSTRAINT funcionarios_cpf_key UNIQUE (cpf)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.funcionarios
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.item_venda
(
    id_item integer NOT NULL DEFAULT nextval('item_venda_id_item_seq'::regclass),
    venda_id integer NOT NULL,
    produto_id integer NOT NULL,
    quantidade integer NOT NULL,
    preco_unidade numeric(10,2) NOT NULL,
    CONSTRAINT item_venda_pkey PRIMARY KEY (id_item),
    CONSTRAINT item_venda_produto_id_fkey FOREIGN KEY (produto_id)
        REFERENCES public.produto (id_produto) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT item_venda_venda_id_fkey FOREIGN KEY (venda_id)
        REFERENCES public.venda (id_venda) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.item_venda
    OWNER to postgres;


CREATE TABLE IF NOT EXISTS public.produto
(
    id_produto integer NOT NULL DEFAULT nextval('produto_id_produto_seq'::regclass),
    no_produto character varying(30) COLLATE pg_catalog."default" NOT NULL,
    descricao text COLLATE pg_catalog."default",
    quant_prod integer NOT NULL,
    preco numeric(10,2) NOT NULL,
    CONSTRAINT produto_pkey PRIMARY KEY (id_produto)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.produto
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.venda
(
    id_venda integer NOT NULL DEFAULT nextval('venda_id_venda_seq'::regclass),
    cliente_id integer,
    data_venda timestamp without time zone NOT NULL,
    valor_total numeric(10,2) NOT NULL,
    funcionario_id integer,
    CONSTRAINT venda_pkey PRIMARY KEY (id_venda),
    CONSTRAINT venda_cliente_id_fkey FOREIGN KEY (cliente_id)
        REFERENCES public.cliente (id_cliente) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT venda_funcionario_id_fkey FOREIGN KEY (funcionario_id)
        REFERENCES public.funcionarios (id_funcionario) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.venda
    OWNER to postgres;

select * from venda;
select * from produto;
select * from funcionarios;
select * from item_venda;
select * from cliente;


