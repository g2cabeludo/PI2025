package ete.pirepositorio;

import ete.negocios.Funcion�rio;
import ete.banco.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RepFuncionario { //senha com md5 n�o aparece no bd!!
    
    Connection con;
    
    public boolean inserir(Funcion�rio funcion�rio) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into funcionarios (no_funcionario, cpf, telefone, senha) values "
                + "(?,?,?,md5(?))";
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        
        stmt.setString(1, funcion�rio.getNome());
        stmt.setString(2, funcion�rio.getCpf());
        stmt.setString(3, funcion�rio.getSenha());

        
        stmt.execute();
        con.commit();
        JOptionPane.showMessageDialog(null, "Funcion�rio salvo");
        ConexaoBanco.fecharConexao(con);
        
        return true;
     }catch(Exception ex){
         try{
             con.rollback();
         }catch(SQLException rollbackEx){
             rollbackEx.printStackTrace();
         }
         JOptionPane.showMessageDialog(null, "Erro ao salvar funcion�rio");
         return false;
     }          
    }
    
}
