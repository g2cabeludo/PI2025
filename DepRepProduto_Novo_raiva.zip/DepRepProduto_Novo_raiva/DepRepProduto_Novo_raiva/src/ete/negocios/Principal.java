package ete.negocios;


import ete.negocios.Funcionario;

import java.util.Date;


public class Principal {
    public static void main(String[] args) {
        
        Funcionario a = new Funcionario(1,"BIUZIN DO FARELO", "123.456.789.30", new Date(), "admin","biu");
        System.out.println("ID: "+a.getId());
        System.out.println("Aributos de Funcionario \n\nNome:  "+a.getNome());
        System.out.println("CPF: "+a.getCpf());
        System.out.println("Data de nascimento: "+a.getData_nascimento());
        System.out.println("Cargo: "+a.getCargo());
        
        
    }
    
}
