
package ete.banco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TesteConexao {
    public static void main(String[]args){
        try (Connection conexao = ConexaoBanco.conectar()){
            
            if(conexao != null && !conexao.isClosed()){
                
                System.out.println("Conex�o com o banco estabelecida com sucesso!");
                
                String sql = "SELECT 1";
                
                try(PreparedStatement stmt = conexao.prepareStatement(sql);
                        ResultSet rs = stmt.executeQuery()){
                    if (rs.next()){
                        System.out.println("Query executada com sucesso: "+rs.getInt(1));
                    }
                }
            
        }else{
                System.out.println("Falha: Conex�o esta fechada ou nula.");  
            }
              
        }catch (SQLException e){
            System.out.println("Erro ao conectar ou executar query: "+e.getMessage());
            e.printStackTrace();
        }
        
    }
    
}
