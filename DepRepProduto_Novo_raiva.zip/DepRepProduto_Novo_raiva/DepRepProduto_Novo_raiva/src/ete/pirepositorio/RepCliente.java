package ete.pirepositorio;


import ete.banco.ConexaoBanco;
import ete.negocios.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class RepCliente {
    Connection con;
    
    public boolean inserir(Cliente cliente) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into cliente (no_cliente, cpf, senha, telefone, data_nasc) values "
                + "(?,?,md5(?),?,?)";
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getCpf());
        stmt.setString(3, cliente.getSenha());
        stmt.setString(4, cliente.getTelefone());
        java.util.Date data = cliente.getData_nascimento();
        stmt.setDate(5, new java.sql.Date(data.getTime()));

        
        stmt.executeUpdate();
        con.commit();
        JOptionPane.showMessageDialog(null, "Cliente salvo");
       
        
        return true;
        
     }catch (Exception ex){
         if(con!=null){
         try{
             con.rollback();
             JOptionPane.showMessageDialog(null, "Erro ao inserir Cliente");
             return false;
         }catch(SQLException exSql){
             System.err.println(exSql.getMessage());
         }
         }
         return false;
     }finally{
        ConexaoBanco.fecharConexao(con);
    }
    }
    
    public List<Cliente> retornar() throws SQLException{
        con = (Connection )ConexaoBanco.conectar();
        List<Cliente> clientes = new ArrayList<>();
        
        String sql = "select * from cliente order by id_cliente desc";
        
        try{
            
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()){
                
                Cliente cliente = new Cliente();
                
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setNome(rs.getString("no_cliente"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setSenha(rs.getString("senha"));
                cliente.setData_nascimento(rs.getDate("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                
               clientes.add(cliente);
                
            }
        }catch(SQLException ex){
            return null;
            
        }finally{
        ConexaoBanco.fecharConexao(con);
    }
           return clientes;
    }
    
    public Cliente achar(String cpf)throws SQLException{
        con = (Connection) ConexaoBanco.conectar();
        Cliente cliente = null;
        
        String sql = "select * from cliente where cpf = ?";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if(rs.next()){
                cliente = new Cliente();
                
                cliente.setId(rs.getInt("id_cliente"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setNome(rs.getString("no_cliente"));
                cliente.setData_nascimento(rs.getDate("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setSenha(rs.getString("senha"));
            }
        }catch(SQLException ex){
            System.err.println("Erro ao buscar cliente: " + ex.getMessage());
            return null;
        }finally{
            ConexaoBanco.fecharConexao(con);
        }
        return cliente;
    }
    
    public boolean atualizar(Cliente cliente)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "update cliente set senha = md5(?) where cpf = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cliente.getSenha());
            stmt.setString(2, cliente.getCpf());
            
            stmt.executeUpdate();
            
            con.commit();
           
            
            return true;
        }catch(SQLException ex){
            if(con !=null){
            try{
                con.rollback();
                System.err.println(ex);
                return false;
            }catch(SQLException ex1){
                System.err.println(ex1);
            }
        }
             return false;
        }finally{
    ConexaoBanco.fecharConexao(con);
    }
   }
    
    public boolean excluir (int id)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        String sql = "delete from cliente where id_cliente = ?";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setInt(1, id);
            
            int linhasAfetadas = stmt.executeUpdate();
            con.commit();
          
            
            return linhasAfetadas>0;
            
        }catch(SQLException ex){
            if (con != null) {
            try {
                con.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erro no rollback: " + rollbackEx);
            }
        }
        System.err.println("Erro ao excluir cliente: " + ex);
        return false;
    } finally  {
            ConexaoBanco.fecharConexao(con);
            
        }
    }
    
    public int login(String cpf, String senha) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        int ret=0;
        
        String sql = "Select count(*) as total from cliente where cpf = ? and senha = ?";
        
        try{
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, cpf);
            pstmt.setString(2, senha);
            
            
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next()){
                ret = rs.getInt("total");
            }
            
            rs.close();
            pstmt.close();
        }catch(SQLException ex){
            System.err.println("Erro no login: " + ex.getMessage());
            return ret;
        }finally{
        ConexaoBanco.fecharConexao(con);
    }
        return ret;
    }
    
    public Cliente procurar(int id) throws SQLException {
        Cliente cliente = null;
        con = (Connection) ConexaoBanco.conectar();

        String sql = "SELECT * FROM cliente WHERE id_cliente = ?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setId(rs.getInt("id_cliente"));
                    cliente.setNome(rs.getString("no_cliente"));
                    cliente.setCpf(rs.getString("cpf"));
                    cliente.setTelefone(rs.getString("telefone"));
                    cliente.setData_nascimento(rs.getDate("data_nasc"));
                }
            }
        } catch (SQLException ex) {
            System.err.println("Erro ao procurar cliente: " + ex.getMessage());
            throw ex;
        } finally {
            ConexaoBanco.fecharConexao(con);
        }

        return cliente;
    }
 }

