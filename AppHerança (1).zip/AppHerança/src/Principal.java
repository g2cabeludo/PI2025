
import java.util.Date;


public class Principal {
    public static void main(String[] args) {
        
        Aluno i = new Aluno("Jose Francisco", "123.456.789-00", new Date(), "1234");
        Aluno j = new Aluno("Neymar Junior", "123.456.789.10", new Date(), "5678");
        Aluno o = new Aluno("Cristiano Ronaldo", "123.456.789-20", new Date(), "7890");
        System.out.println("Veja como os atributos foram preenchidos\n\nNome: "+i.nome);
        System.out.println("CPF: "+i.cpf);
        System.out.println("Data de nascimento: "+i.data_nascimento.toString());
        System.out.println("Matr�cula: "+i.matricula);
        
        System.out.println("Veja como os atributos foram preenchidos\n\nNome: "+j.nome);
        System.out.println("CPF: "+j.cpf);
        System.out.println("Data de nascimento: "+j.data_nascimento.toString());
        System.out.println("Matr�cula: "+j.matricula);
        
        System.out.println("Veja como os atributos foram preenchidos\n\nNome: "+o.nome);
        System.out.println("CPF: "+o.cpf);
        System.out.println("Data de nascimento: "+o.data_nascimento.toString());
        System.out.println("Matr�cula: "+o.matricula);
        
        Funcion�rio a = new Funcion�rio("Cleber Machado", "123.456.789.30", new Date(), 1.234, new Date(), "admin");
        System.out.println("Aributos de Funcion�rio \n\nNome:  "+a.nome);
        System.out.println("CPF: "+a.cpf);
        System.out.println("Data de nascimento: "+a.data_nascimento);
        System.out.println("Salario: "+a.salario);
        System.out.println("Data de admiss�o: "+a.data_admissao);
        System.out.println("Carfo: "+a.cargo);
        
        
    }
    
}
