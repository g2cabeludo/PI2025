import java.util.Date;
public class Professor {
    public double salario;
    public String disciplina;
    public Professor(String _nome, String _cpf, Date _data, double salario, String disciplina){
         super(_nome, _cpf, _data);
        this.salario = salario;
        this.disciplina = disciplina;
    }
    
}
