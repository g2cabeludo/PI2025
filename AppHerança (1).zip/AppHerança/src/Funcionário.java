
import java.util.Date;


public class Funcion�rio extends Pessoa{
    public double salario;
    public Date data_admissao;
    public String cargo;
    public Funcion�rio(String _nome, String _cpf, Date _data, double salario, 
            Date data_admissao, String cargo){
            super(_nome, _cpf, _data);
            this.salario = salario;
            this.cargo = cargo;
            this.data_admissao = data_admissao;
    } 

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Date getData_admissao() {
        return data_admissao;
    }

    public void setData_admissao(Date data_admissao) {
        this.data_admissao = data_admissao;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(Date data_nascimento) {
        this.data_nascimento = data_nascimento;
    }
    
}
