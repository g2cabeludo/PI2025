package ete.negocios;


import java.util.Date;


public class Funcion�rio extends Pessoa{
    public String cargo;
    public Funcion�rio(int id, String _nome, String _cpf, Date _data, String cargo){
            super(_nome, _cpf, _data, id);
            
            this.cargo = cargo;
         
    } 

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(Date data_nascimento) {
        this.data_nascimento = data_nascimento;
    }
    
}
